#include "Animal.h"
/**
 * Destructor
 */
CAnimal::~CAnimal()
{
}